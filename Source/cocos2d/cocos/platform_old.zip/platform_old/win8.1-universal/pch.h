﻿//
// pch.h
// Header for standard system include files.
//

#pragma once

#include <collection.h>
#include <ppltasks.h>

#include "cocos2d.h"
#include "cocos-ext.h"


