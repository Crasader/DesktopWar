
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionAttackFar : public PawnAction
	{
	public:

		PawnActionAttackFar();

		virtual void Reset();

	};

}