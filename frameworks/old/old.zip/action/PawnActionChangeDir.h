
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionChangeDir : public PawnAction
	{
	public:

		PawnActionChangeDir();

		virtual void Reset();

	};

}