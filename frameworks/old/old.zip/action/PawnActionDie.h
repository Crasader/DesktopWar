
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionDie : public PawnAction
	{
	public:

		PawnActionDie();

		virtual void Reset();

	};

}