
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionSkill2 : public PawnAction
	{
	public:

		PawnActionSkill2();

		virtual void Reset();

	};

}