
#include "PawnActionSkill3.h"
#include "ActionDefine.h"

using namespace Genius;

PawnActionSkill3::PawnActionSkill3()
{
	m_actionType = PAT_Skill3;
}

void PawnActionSkill3::Reset()
{
	PawnAction::Reset();
}