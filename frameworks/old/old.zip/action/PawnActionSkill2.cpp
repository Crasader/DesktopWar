
#include "PawnActionSkill2.h"
#include "ActionDefine.h"

using namespace Genius;

PawnActionSkill2::PawnActionSkill2()
{
	m_actionType = PAT_Skill2;
}

void PawnActionSkill2::Reset()
{
	PawnAction::Reset();
}