
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionSkill3 : public PawnAction
	{
	public:

		PawnActionSkill3();

		virtual void Reset();

	};

}