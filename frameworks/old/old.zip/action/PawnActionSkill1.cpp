
#include "PawnActionSkill1.h"
#include "ActionDefine.h"

using namespace Genius;

PawnActionSkill1::PawnActionSkill1()
{
	m_actionType = PAT_Skill1;
}

void PawnActionSkill1::Reset()
{
	PawnAction::Reset();
}