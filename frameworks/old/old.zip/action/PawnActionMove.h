
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionMove : public PawnAction
	{
	public:

		PawnActionMove();

		virtual void Reset();

	};

}