
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionAttackNear : public PawnAction
	{
	public:

		PawnActionAttackNear();

		virtual void Reset();

	};

}