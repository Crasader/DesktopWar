
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionSkill1 : public PawnAction
	{
	public:

		PawnActionSkill1();

		virtual void Reset();

	};

}