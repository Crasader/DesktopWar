
#pragma once

#include "PawnAction.h"


namespace Genius
{

	class PawnActionIdle : public PawnAction
	{
	public:

		PawnActionIdle();

		virtual void Reset();

	};

}