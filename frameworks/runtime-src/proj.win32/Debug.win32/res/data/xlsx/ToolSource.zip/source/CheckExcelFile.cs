﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CSOpenXmlExcelToCheckExcel
{
    public class CheckExcelFile
    {
        /// <summary>
        ///  Read Data from selected excel file into DataTable
        /// </summary>
        /// <param name="filename">Excel File Path</param>
        /// <returns></returns>
        public string ReadExcelFile(string filename)
        {
            // Initialize an instance of DataTable
            DataTable dt = new DataTable();
            try
            {
                // Use SpreadSheetDocument class of Open XML SDK to open excel file
                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(filename, false))
                {
                    // Get Workbook Part of Spread Sheet Document
                    WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;

                    // Get all sheets in spread sheet document 
                    IEnumerable<Sheet> sheetcollection = spreadsheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();

                    // Get relationship Id
                    string relationshipId = sheetcollection.First().Id.Value;

                    // Set DataTable's TableName
                    dt.TableName = sheetcollection.First().Name;

                    // Get sheet1 Part of Spread Sheet Document
                    WorksheetPart worksheetPart = (WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(relationshipId);

                    // Get Data in Excel file
                    SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
                    IEnumerable<Row> rowcollection = sheetData.Descendants<Row>();

                    if (rowcollection.Count() == 0)
                    {
                        return filename + " 文件为空!";
                    }
                    if (rowcollection.Count() < 5)
                    {
                        return filename + " 文件的前5行必须填写完整!";
                    }

                    // Add columns
                    foreach (Cell cell in rowcollection.ElementAt(0))
                    {
                        dt.Columns.Add(GetValueOfCell(spreadsheetDocument, cell));
                    }

                    int ColumnsLength = dt.Columns.Count;
                    if (ColumnsLength < 2)
                    {
                        return filename + " 文件至少两列!";
                    }

                    foreach (Row row in rowcollection)
                    {
                        if (row.RowIndex < 5)
                        {
                            int count = 0;
                            foreach (Cell cell in row.Descendants<Cell>())
                            {
                                string cellInfo = GetValueOfCell(spreadsheetDocument, cell);
                                count++;
                            }
                            if (ColumnsLength != count)
                            {
                                return filename + " 文件的前5行必须填写完整";
                            }
                        }
                        else
                            break;
                    }

                    
                    #region CheckOut Type Of Variable
                                        
                    string[] variableLength = new string[ColumnsLength];
                    string[] variableType = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.ElementAt(3).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        if (cellColumnIndex >= 2)
                        {
                            string cellInfo = GetValueOfCell(spreadsheetDocument, cell);
                            variableLength[cellColumnIndex] = "";
                            variableType[cellColumnIndex] = cellInfo;

                            //array
                            if (cellInfo.EndsWith("]"))
                            {
                                int startIndex = cellInfo.IndexOf('[');
                                variableLength[cellColumnIndex] = cellInfo.Substring(startIndex + 1, cellInfo.Length - startIndex - 2);
                                variableType[cellColumnIndex] = cellInfo.Substring(0, startIndex);
                            }
                        }
                    }

                    foreach (Row row in rowcollection)
                    {
                        if (row.RowIndex > 5)
                        {
                            foreach (Cell cell in row.Descendants<Cell>())
                            {
                                int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                                if (cellColumnIndex >= 2)
                                {
                                    string cellInfo = GetValueOfCell(spreadsheetDocument, cell);

                                    if (variableLength[cellColumnIndex].Equals(""))
                                    {
                                        if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float")
                                           || variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long")
                                           || variableType[cellColumnIndex].Equals("bool"))
                                        {   
                                            if(!IsNumeric(cellInfo))
                                            {
                                                //return filename +　" 中第" + row.RowIndex + "行、第" + GetColumnName(cell.CellReference) + "列数据类型填写错误!";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        // Checkout Array
                                    }
                                }
                            }
                        }
                    } 

                    #endregion
                }
                return "";
            }
            catch (IOException ex)
            {
                throw new IOException(ex.Message);
            }
        }

        public static bool IsNumeric(string value)
        {
            return Regex.IsMatch(value, @"^[+-]?\d*[.]?\d*$");
        }

        /// <summary>
        ///  Get Value of Cell 
        /// </summary>
        /// <param name="spreadsheetdocument">SpreadSheet Document Object</param>
        /// <param name="cell">Cell Object</param>
        /// <returns>The Value in Cell</returns>
        private static string GetValueOfCell(SpreadsheetDocument spreadsheetdocument, Cell cell)
        {
            // Get value in Cell
            SharedStringTablePart sharedString = spreadsheetdocument.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
            {
                return string.Empty;
            }

            string cellValue = cell.CellValue.InnerText;
            
            // The condition that the Cell DataType is SharedString
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return sharedString.SharedStringTable.ChildElements[int.Parse(cellValue)].InnerText;
            }
            else
            {
                return cellValue;
            }
        }

        /// <summary>
        /// Get Column Name From given cell name
        /// </summary>
        /// <param name="cellReference">Cell Name(For example,A1)</param>
        /// <returns>Column Name(For example, A)</returns>
        private string GetColumnName(string cellReference)
        {
            // Create a regular expression to match the column name of cell
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellReference);
            return match.Value;
        }

        /// <summary>
        /// Get Index of Column from given column name
        /// </summary>
        /// <param name="columnName">Column Name(For Example,A or AA)</param>
        /// <returns>Column Index</returns>
        private int GetColumnIndex(string columnName)
        {
            int columnIndex = 0;
            int factor = 1;

            // From right to left
            for (int position = columnName.Length - 1; position >= 0; position--)
            {
                // For letters
                if (Char.IsLetter(columnName[position]))
                {
                    columnIndex += factor * ((columnName[position] - 'A') + 1) - 1;
                    factor *= 26;
                }
            }

            return columnIndex;
        }
    }
}
