﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CSOpenXmlExcelToCS
{
    public class XlsxToCS
    {
        /// <summary>
        ///  Read Data from selected excel file into DataTable
        /// </summary>
        /// <param name="filename">Excel File Path</param>
        /// <returns></returns>
        public string ReadExcelFile(string filename)
        {
            // Initialize an instance of DataTable
            DataTable dt = new DataTable();
            string csFile = "";

            try
            {
                // Use SpreadSheetDocument class of Open XML SDK to open excel file
                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(filename, false))
                {
                    // Get Workbook Part of Spread Sheet Document
                    WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;

                    // Get all sheets in spread sheet document 
                    IEnumerable<Sheet> sheetcollection = spreadsheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();

                    // Get relationship Id
                    string relationshipId = sheetcollection.First().Id.Value;

                    // Set DataTable's TableName
                    dt.TableName = sheetcollection.First().Name;

                    // Get sheet1 Part of Spread Sheet Document
                    WorksheetPart worksheetPart = (WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(relationshipId);

                    // Get Data in Excel file
                    SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
                    IEnumerable<Row> rowcollection = sheetData.Descendants<Row>();

                    if (rowcollection.Count() == 0)
                    {
                        return null;
                    }

                    // Add columns
                    foreach (Cell cell in rowcollection.ElementAt(0))
                    {
                        dt.Columns.Add(GetValueOfCell(spreadsheetDocument, cell));
                    }

                    int ColumnsLength = dt.Columns.Count;

                    // Get variableName array
                    // the first row is variableName
                    string[] variableName = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.First().Descendants<Cell>())
                    {
                        string a = GetColumnName(cell.CellReference);
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));

                        variableName[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
                    }

                    // Get variableDescribe array
                    // the second row is variableDescribe
                    string[] variableDescribe = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.ElementAt(1).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        variableDescribe[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
                    }

                    // Add variableName Info To CS
                    // the third row is variableType
                    string[] variableLength = new string[ColumnsLength];
                    string[] variableType = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.ElementAt(3).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        if (cellColumnIndex >= 2)
                        {
                            string cellInfo = GetValueOfCell(spreadsheetDocument, cell);
                            variableLength[cellColumnIndex] = "";
                            variableType[cellColumnIndex] = cellInfo;

                            //array
                            if (cellInfo.EndsWith("]"))
                            {
                                int startIndex = cellInfo.IndexOf('[');
                                variableLength[cellColumnIndex] = cellInfo.Substring(startIndex + 1, cellInfo.Length - startIndex - 2);
                                variableType[cellColumnIndex] = cellInfo.Substring(0, startIndex);
                            }
                            //Test
                            //Char end = cellInfo[cellInfo.Length - 1];
                            //if (Char.IsNumber(end))
                            //{
                            //    int startIndex = cellInfo.IndexOf('[');
                            //    variableLength[cellColumnIndex] = cellInfo.Substring(startIndex + 1, cellInfo.Length - startIndex - 1);
                            //    variableType[cellColumnIndex] = cellInfo.Substring(0, startIndex);
                            //}

                            if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float") ||
                                variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long") ||
                                variableType[cellColumnIndex].Equals("string") || variableType[cellColumnIndex].Equals("bool") ||
                                variableType[cellColumnIndex].Equals("JObject"))
                            {
                                if (variableLength[cellColumnIndex].Equals(""))
                                {
                                    csFile += "\t\t" + variableType[cellColumnIndex] + " _" + variableName[cellColumnIndex] + ";\t//" + variableDescribe[cellColumnIndex] + "\n";
                                    csFile += "\t\tpublic " + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + " { get { return _" + variableName[cellColumnIndex] + ";} }\n";
                                    csFile += "\n";
                                }
                                else
                                {
                                    csFile += "\t\t" + variableType[cellColumnIndex] + "[] _" + variableName[cellColumnIndex] + " = new " + variableType[cellColumnIndex] + "[" + variableLength[cellColumnIndex] + "];\t//" + variableDescribe[cellColumnIndex] + "\n";
                                    csFile += "\t\tpublic " + variableType[cellColumnIndex] + "[] " + variableName[cellColumnIndex] + " { get { return _" + variableName[cellColumnIndex] + ";} }\n";
                                    csFile += "\n";
                                }
                            }
                        }
                    }

                    // Add Init() Info To CS
                    // Get variableDefaultValue array
                    // the fourth row is variableDefaultValue
                    string[] variableDefaultValue = new string[ColumnsLength];
					csFile += "\t\tpublic override int init(TabFileReader reader, int row, int column)" + "\n";
                    csFile += "\t\t{" + "\n";
					csFile += "\t\t\tcolumn = base.init(reader, row, column);" + "\n\n";
                    foreach (Cell cell in rowcollection.ElementAt(4).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        if (cellColumnIndex >= 2)
                        {
                            variableDefaultValue[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);

                            //special deal with bool
                            if (variableType[cellColumnIndex].Equals("bool"))
                            {
                                if (variableDefaultValue[cellColumnIndex].Equals("0"))
                                    variableDefaultValue[cellColumnIndex] = "false";
                                else
                                    variableDefaultValue[cellColumnIndex] = "true";
                            }

                            if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float") ||
                                variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long") ||
                                variableType[cellColumnIndex].Equals("bool"))
                            {
                                if (variableLength[cellColumnIndex].Equals(""))
                                {
                                    csFile += "\t\t\t_" + variableName[cellColumnIndex] + " = " + variableDefaultValue[cellColumnIndex] + ";\n";
									csFile += "\t\t\t" + variableType[cellColumnIndex] + ".TryParse(reader.Index(row, column), out _" + variableName[cellColumnIndex] + ");\n";
                                }
                                else
                                {
									// default value
									csFile += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++)" + "\n";
									csFile += "\t\t\t\t_" + variableName[cellColumnIndex] + "[i] = " + variableDefaultValue[cellColumnIndex] + ";\n";

									csFile += "\t\t\tstring[] " + variableName[cellColumnIndex] + "Array = reader.Index(row, column).Split(\',\');" + "\n";
									csFile += "\t\t\tint " + variableName[cellColumnIndex] + "Count = " + variableName[cellColumnIndex] + "Array.Length;" + "\n";
                                    csFile += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++)\n";
									csFile += "\t\t\t{\n";
                                    csFile += "\t\t\t\tif(i < " + variableName[cellColumnIndex] + "Count)" + "\n";
									csFile += "\t\t\t\t\t" + variableType[cellColumnIndex] + ".TryParse(" + variableName[cellColumnIndex] + "Array[i], out _" + variableName[cellColumnIndex] + "[i]);" + "\n";
                                    csFile += "\t\t\t\telse" + "\n";
                                    csFile += "\t\t\t\t\t_" + variableName[cellColumnIndex] + "[i] = " + variableDefaultValue[cellColumnIndex] + ";\n";
                                    csFile += "\t\t\t}\n";
                                }
                            }
                            if (variableType[cellColumnIndex].Equals("string"))
                            {
                                if (variableLength[cellColumnIndex].Equals(""))
                                {
									csFile += "\t\t\tif(reader.Index(row, column) == null)" + "\n";
                                    csFile += "\t\t\t\t_" + variableName[cellColumnIndex] + " = " + variableDefaultValue[cellColumnIndex] + ";\n";
                                    csFile += "\t\t\telse" + "\n";
									csFile += "\t\t\t\t_" + variableName[cellColumnIndex] + " = reader.Index(row, column);\n";
                                }
                                else
                                {
									csFile += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++)" + "\n";
									csFile += "\t\t\t\t_" + variableName[cellColumnIndex] + "[i] = " + variableDefaultValue[cellColumnIndex] + ";\n";

									csFile += "\t\t\tstring[] " + variableName[cellColumnIndex] + "Array = reader.Index(row, column).Split(\',\');" + "\n";
									csFile += "\t\t\tint " + variableName[cellColumnIndex] + "Count = " + variableName[cellColumnIndex] + "Array.Length;" + "\n";
                                    csFile += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++){" + "\n";
                                    csFile += "\t\t\t\tif(i < " + variableName[cellColumnIndex] + "Count)" + "\n";
									csFile += "\t\t\t\t\t_" + variableName[cellColumnIndex] + "[i] = " + variableName[cellColumnIndex] + "Array[i];\n";
                                    csFile += "\t\t\t\telse" + "\n";
                                    csFile += "\t\t\t\t\t_" + variableName[cellColumnIndex] + "[i] = " + variableDefaultValue[cellColumnIndex] + ";\n";
                                    csFile += "\t\t\t}\n";
                                }
                            }
                            // JObject
                            if (variableType[cellColumnIndex].Equals("JObject"))
                            {
                                csFile += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++){" + "\n";
								csFile += "\t\t\t\tJArray ja = (JArray)JsonConvert.DeserializeObject(reader.Index(row, column));\n";
                                csFile += "\t\t\t\t_" + variableName[cellColumnIndex] + "[i] = (JObject)ja[i];\n";
                                csFile += "\t\t\t}\n";
                            }

							csFile += "\t\t\tcolumn++;\n";
							csFile += "\n";

                        }
                    }
					csFile += "\t\t\treturn column;\n";
                    csFile += "\t\t}\n";
                }
                return csFile;
            }
            catch (IOException ex)
            {
                throw new IOException(ex.Message);
            }
        }

        /// <summary>
        ///  Get Value of Cell 
        /// </summary>
        /// <param name="spreadsheetdocument">SpreadSheet Document Object</param>
        /// <param name="cell">Cell Object</param>
        /// <returns>The Value in Cell</returns>
        private static string GetValueOfCell(SpreadsheetDocument spreadsheetdocument, Cell cell)
        {
            // Get value in Cell
            SharedStringTablePart sharedString = spreadsheetdocument.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
            {
                return string.Empty;
            }

            string cellValue = cell.CellValue.InnerText;

            // The condition that the Cell DataType is SharedString
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return sharedString.SharedStringTable.ChildElements[int.Parse(cellValue)].InnerText;
            }
            else
            {
                return cellValue;
            }
        }


        /// <summary>
        /// Get Column Name From given cell name
        /// </summary>
        /// <param name="cellReference">Cell Name(For example,A1)</param>
        /// <returns>Column Name(For example, A)</returns>
        private string GetColumnName(string cellReference)
        {
            // Create a regular expression to match the column name of cell
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellReference);
            return match.Value;
        }

        /// <summary>
        /// Get Index of Column from given column name
        /// </summary>
        /// <param name="columnName">Column Name(For Example,A or AA)</param>
        /// <returns>Column Index</returns>
        private int GetColumnIndex(string columnName)
        {
            int columnIndex = 0;
            int factor = 1;

            // From right to left
            for (int position = columnName.Length - 1; position >= 0; position--)
            {
                // For letters
                if (Char.IsLetter(columnName[position]))
                {
                    columnIndex += factor * ((columnName[position] - 'A') + 1) - 1;
                    factor *= 26;
                }
            }

            if ((columnName.Length - 1) >= 1)
            {
                //columnIndex += 1 + (columnName[columnName.Length - 2] - 'A');
                columnIndex += 1;
            }

            return columnIndex;
        }
    }
}
