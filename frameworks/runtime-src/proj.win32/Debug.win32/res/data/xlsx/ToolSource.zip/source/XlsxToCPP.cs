﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;


public class XlsxToCPP
{
	/// <summary>
	///  Read Data from selected excel file into DataTable
	/// </summary>
	/// <param name="filename">Excel File Path</param>
	/// <returns></returns>
	public void ReadExcelFile(string filename, string className, out string hppString, out string cppString)
	{
		// Initialize an instance of DataTable
		DataTable dt = new DataTable();
		hppString = "";
		cppString = "";

		try
		{
			// Use SpreadSheetDocument class of Open XML SDK to open excel file
			using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(filename, false))
			{
				// Get Workbook Part of Spread Sheet Document
				WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;

				// Get all sheets in spread sheet document 
				IEnumerable<Sheet> sheetcollection = spreadsheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();

				// Get relationship Id
				string relationshipId = sheetcollection.First().Id.Value;

				// Set DataTable's TableName
				dt.TableName = sheetcollection.First().Name;

				// Get sheet1 Part of Spread Sheet Document
				WorksheetPart worksheetPart = (WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(relationshipId);

				// Get Data in Excel file
				SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
				IEnumerable<Row> rowcollection = sheetData.Descendants<Row>();

				if (rowcollection.Count() == 0)
				{
					return;
				}

				// Add columns
				foreach (Cell cell in rowcollection.ElementAt(0))
				{
					dt.Columns.Add(GetValueOfCell(spreadsheetDocument, cell));
				}

				int ColumnsLength = dt.Columns.Count;

				// Get variableName array
				// the first row is variableName
				string[] variableName = new string[ColumnsLength];
				foreach (Cell cell in rowcollection.First().Descendants<Cell>())
				{
					string a = GetColumnName(cell.CellReference);
					int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));

					variableName[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
				}

				// Get variableDescribe array
				// the second row is variableDescribe
				string[] variableDescribe = new string[ColumnsLength];
				foreach (Cell cell in rowcollection.ElementAt(1).Descendants<Cell>())
				{
					int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
					variableDescribe[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
				}

				// Add variableName Info To Cpp
				// the third row is variableType
				string[] variableLength = new string[ColumnsLength];
				string[] variableType = new string[ColumnsLength];
				foreach (Cell cell in rowcollection.ElementAt(3).Descendants<Cell>())
				{
					int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
					if (cellColumnIndex >= 2)
					{
						string cellInfo = GetValueOfCell(spreadsheetDocument, cell);
						variableLength[cellColumnIndex] = "";
						variableType[cellColumnIndex] = cellInfo;

						//array
						if (cellInfo.EndsWith("]"))
						{
							int startIndex = cellInfo.IndexOf('[');
							variableLength[cellColumnIndex] = cellInfo.Substring(startIndex + 1, cellInfo.Length - startIndex - 2);
							variableType[cellColumnIndex] = cellInfo.Substring(0, startIndex);
						}

						if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float") ||
							variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long") ||
							variableType[cellColumnIndex].Equals("string") || variableType[cellColumnIndex].Equals("bool") ||
							variableType[cellColumnIndex].Equals("JObject"))
						{
							if (variableLength[cellColumnIndex].Equals(""))
							{
								hppString += "\t\t" + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + ";\n";
							}
							else
							{
								hppString += "\t\t" + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + "[" + variableLength[cellColumnIndex] + "];\n";
							}
						}
					}
				}

				Dictionary<string, string> typeParseDic = new Dictionary<string, string>()
				{
					{"int", "GetIntValue"},
					{"float", "GetFloatValue"},
					{"double", "GetDoubleValue"},
					{"long", "GetLongValue"},
					{"bool", "GetBoolValue"},
					{"string", "GetStringValue"},
				};

				Dictionary<string, string> typeParseDic2 = new Dictionary<string, string>()
				{
					{"int", "ToInt"},
					{"float", "ToFloat"},
					{"double", "ToDouble"},
					{"long", "ToLong"},
					{"bool", "ToBool"},
					{"string", "ToString"},
				};

				// Add Init()
				// Get variableDefaultValue array
				// the fourth row is variableDefaultValue
				string[] variableDefaultValue = new string[ColumnsLength];
				cppString += "\n\t\tint " + className + "::Init(Genius::TabFile& reader, int row, int col)" + "\n";
				cppString += "\t\t{" + "\n";
				cppString += "\t\t\tcol = BaseConfig::Init(reader, row, col);\n\n";
				
				foreach (Cell cell in rowcollection.ElementAt(4).Descendants<Cell>())
				{
					int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
					if (cellColumnIndex >= 2)
					{
						variableDefaultValue[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);

						if (!typeParseDic.ContainsKey(variableType[cellColumnIndex]))
							continue;

						if (variableLength[cellColumnIndex].Equals(""))
						{
							cppString += "\t\t\t" + variableName[cellColumnIndex] + " = " + variableDefaultValue[cellColumnIndex] + ";\n";
							cppString += "\t\t\tif(reader.GetStringValue(row, col).length() > 0)\n";
							cppString += "\t\t\t\t" + variableName[cellColumnIndex] + " = reader." + typeParseDic[variableType[cellColumnIndex]] + "(row, col++);\n";
						}
						else
						{
							// default value
							cppString += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++)" + "\n";
							cppString += "\t\t\t\t" + variableName[cellColumnIndex] + "[i] = " + variableDefaultValue[cellColumnIndex] + ";\n";

							cppString += "\t\t\tvector<string> " + variableName[cellColumnIndex] + "Array = reader.Split(reader.GetStringValue(row, col++), cfg::BaseConfig::Separator);" + "\n";
							cppString += "\t\t\tint " + variableName[cellColumnIndex] + "Count = " + variableName[cellColumnIndex] + "Array.size();" + "\n";
							cppString += "\t\t\tfor(int i=0; i<" + variableLength[cellColumnIndex] + "; i++)\n";
							cppString += "\t\t\t{\n";
							cppString += "\t\t\t\tif(i < " + variableName[cellColumnIndex] + "Count)" + "\n";
							cppString += "\t\t\t\t\t" + variableName[cellColumnIndex] + "[i] = reader." + typeParseDic2[variableType[cellColumnIndex]] + "(" + variableName[cellColumnIndex] + "Array[i]);\n";
							cppString += "\t\t\t\telse" + "\n";
							cppString += "\t\t\t\t\t" + variableName[cellColumnIndex] + "[i] = " + variableDefaultValue[cellColumnIndex] + ";\n";
							cppString += "\t\t\t}\n";
						}

						cppString += "\n";

					}
				}
				cppString += "\t\t\treturn col;\n";
				cppString += "\t\t}\n";
			}
			
		}
		catch (IOException ex)
		{
			throw new IOException(ex.Message);
		}
	}

	/// <summary>
	///  Get Value of Cell 
	/// </summary>
	/// <param name="spreadsheetdocument">SpreadSheet Document Object</param>
	/// <param name="cell">Cell Object</param>
	/// <returns>The Value in Cell</returns>
	private static string GetValueOfCell(SpreadsheetDocument spreadsheetdocument, Cell cell)
	{
		// Get value in Cell
		SharedStringTablePart sharedString = spreadsheetdocument.WorkbookPart.SharedStringTablePart;
		if (cell.CellValue == null)
		{
			return string.Empty;
		}

		string cellValue = cell.CellValue.InnerText;

		// The condition that the Cell DataType is SharedString
		if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
		{
			return sharedString.SharedStringTable.ChildElements[int.Parse(cellValue)].InnerText;
		}
		else
		{
			return cellValue;
		}
	}


	/// <summary>
	/// Get Column Name From given cell name
	/// </summary>
	/// <param name="cellReference">Cell Name(For example,A1)</param>
	/// <returns>Column Name(For example, A)</returns>
	private string GetColumnName(string cellReference)
	{
		// Create a regular expression to match the column name of cell
		Regex regex = new Regex("[A-Za-z]+");
		Match match = regex.Match(cellReference);
		return match.Value;
	}

	/// <summary>
	/// Get Index of Column from given column name
	/// </summary>
	/// <param name="columnName">Column Name(For Example,A or AA)</param>
	/// <returns>Column Index</returns>
	private int GetColumnIndex(string columnName)
	{
		int columnIndex = 0;
		int factor = 1;

		// From right to left
		for (int position = columnName.Length - 1; position >= 0; position--)
		{
			// For letters
			if (Char.IsLetter(columnName[position]))
			{
				columnIndex += factor * ((columnName[position] - 'A') + 1) - 1;
				factor *= 26;
			}
		}

		if ((columnName.Length - 1) >= 1)
		{
			//columnIndex += 1 + (columnName[columnName.Length - 2] - 'A');
			columnIndex += 1;
		}

		return columnIndex;
	}
}

