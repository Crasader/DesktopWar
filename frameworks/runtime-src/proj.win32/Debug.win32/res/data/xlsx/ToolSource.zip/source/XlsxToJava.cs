﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CSOpenXmlExcelToJava
{
    public class XlsxToJava
    {
        /// <summary>
        ///  Read Data from selected excel file into DataTable
        /// </summary>
        /// <param name="filename">Excel File Path</param>
        /// <returns></returns>
        public string ReadExcelFile(string filename, string ExcelFileName)
        {
            // Initialize an instance of DataTable
            DataTable dt = new DataTable();
            string javaFile = "";

            try
            {
                // Use SpreadSheetDocument class of Open XML SDK to open excel file
                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(filename, false))
                {
                    // Get Workbook Part of Spread Sheet Document
                    WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;

                    // Get all sheets in spread sheet document 
                    IEnumerable<Sheet> sheetcollection = spreadsheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();

                    // Get relationship Id
                    string relationshipId = sheetcollection.First().Id.Value;

                    // Set DataTable's TableName
                    dt.TableName = sheetcollection.First().Name;

                    // Get sheet1 Part of Spread Sheet Document
                    WorksheetPart worksheetPart = (WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(relationshipId);

                    // Get Data in Excel file
                    SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
                    IEnumerable<Row> rowcollection = sheetData.Descendants<Row>();

                    if (rowcollection.Count() == 0)
                    {
                        return null;
                    }

                    // Add columns
                    foreach (Cell cell in rowcollection.ElementAt(0))
                    {
                        dt.Columns.Add(GetValueOfCell(spreadsheetDocument, cell));
                    }

                    int ColumnsLength = dt.Columns.Count;

                    // Get variableName array
                    // the first row is variableName
                    string[] variableName = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.First().Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        variableName[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
                    }

                    // Get variableDescribe array
                    // the second row is variableDescribe
                    string[] variableDescribe = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.ElementAt(1).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        variableDescribe[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
                    }

                    // Get variableDefaultValue array
                    // the fourth row is variableDefaultValue
                    string[] variableDefaultValue = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.ElementAt(4).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        variableDefaultValue[cellColumnIndex] = GetValueOfCell(spreadsheetDocument, cell);
                    }

                    // Add variableName Info To CS
                    // the third row is variableType
                    string[] variableLength = new string[ColumnsLength];
                    string[] variableType = new string[ColumnsLength];
                    foreach (Cell cell in rowcollection.ElementAt(3).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        if (cellColumnIndex >= 1)
                        {
                            string cellInfo = GetValueOfCell(spreadsheetDocument, cell);
                            variableLength[cellColumnIndex] = "";
                            variableType[cellColumnIndex] = cellInfo;

                            //array
                            if (cellInfo.EndsWith("]"))
                            {
                                int startIndex = cellInfo.IndexOf('[');
                                variableLength[cellColumnIndex] = cellInfo.Substring(startIndex + 1, cellInfo.Length - startIndex - 2);
                                variableType[cellColumnIndex] = cellInfo.Substring(0, startIndex);
                            }

                            if (variableType[cellColumnIndex].Equals("bool"))
                            {
                                variableType[cellColumnIndex] = "boolean";
                            }
                            if (variableType[cellColumnIndex].Equals("string"))
                            {
                                variableType[cellColumnIndex] = "String";
                            }

                            if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float") ||
                                variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long") ||
                                variableType[cellColumnIndex].Equals("String") || variableType[cellColumnIndex].Equals("boolean"))
                            {
                                if (variableLength[cellColumnIndex].Equals(""))
                                {
                                    if (variableName[cellColumnIndex].Equals("id"))
                                    {
                                        javaFile += "\t@TemplateId" + "\n";
                                        variableType[cellColumnIndex] = "String";
                                    }
                                    javaFile += "\tprivate " + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + ";\t//" + variableDescribe[cellColumnIndex] + "\n";
                                    javaFile += "\n";
                                }
                                else
                                {
                                    if (variableType[cellColumnIndex].Equals("float"))
                                    {
                                        javaFile += "\tprivate " + "List " + variableName[cellColumnIndex] + ";\t//" + variableDescribe[cellColumnIndex] + "\n";
                                        javaFile += "\n";
                                    }
                                    else
                                    {
                                        javaFile += "\tprivate " + variableType[cellColumnIndex] + "[] " + variableName[cellColumnIndex] + " = new " + variableType[cellColumnIndex] + "[" + variableLength[cellColumnIndex] + "];\t//" + variableDescribe[cellColumnIndex] + "\n";
                                        javaFile += "\n";
                                    }
                                }
                            }

                            if (variableType[cellColumnIndex].Equals("JsonData"))
                            {
                                variableType[cellColumnIndex] = "JSONArray";
                                javaFile += "\tprivate " + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + " = new " + variableType[cellColumnIndex] + "();\t//" + variableDescribe[cellColumnIndex] + "\n";
                                javaFile += "\n";
                            }
                        }
                    }

                    javaFile += "\tpublic String getTitle() {\n\t\treturn title;\n\t}\n";
                    javaFile += "\tpublic void setTitle(String title) {\n\t\tthis.title = title;\n\t}\n";

                    foreach (Cell cell in rowcollection.ElementAt(4).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        if (cellColumnIndex >= 1)
                        {
                            string first = variableName[cellColumnIndex][0].ToString();
                            string last = variableName[cellColumnIndex].Substring(1);
                            string strName = first.ToUpper() + last;

                            if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float") ||
                                variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long") ||
                                variableType[cellColumnIndex].Equals("String") || variableType[cellColumnIndex].Equals("boolean"))
                            {
                                if (variableLength[cellColumnIndex].Equals(""))
                                {
                                    javaFile += "\tpublic " + variableType[cellColumnIndex] + " get" + strName + "() {" + "\n";
                                    javaFile += "\t\treturn " + variableName[cellColumnIndex] + ";\n";
                                    javaFile += "\t}\n";

                                    javaFile += "\tpublic void set" + strName + "(" + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + ") {" + "\n";
                                    javaFile += "\t\tthis." + variableName[cellColumnIndex] + " = " + variableName[cellColumnIndex] + ";\n";
                                    javaFile += "\t}\n";
                                }
                                else
                                {
                                    if (variableType[cellColumnIndex].Equals("float"))
                                    {
                                        javaFile += "\tpublic List get" + strName + "() {" + "\n";
                                        javaFile += "\t\treturn " + variableName[cellColumnIndex] + ";\n";
                                        javaFile += "\t}\n";

                                        javaFile += "\tpublic void set" + strName + "(List " + variableName[cellColumnIndex] + ") {" + "\n";
                                        javaFile += "\t\tthis." + variableName[cellColumnIndex] + " = " + variableName[cellColumnIndex] + ";\n";
                                        javaFile += "\t}\n";
                                    }
                                    else
                                    {
                                        javaFile += "\tpublic " + variableType[cellColumnIndex] + "[] get" + strName + "() {" + "\n";
                                        javaFile += "\t\treturn " + variableName[cellColumnIndex] + ";\n";
                                        javaFile += "\t}\n";

                                        javaFile += "\tpublic void set" + strName + "(" + variableType[cellColumnIndex] + "[] " + variableName[cellColumnIndex] + ") {" + "\n";
                                        javaFile += "\t\tthis." + variableName[cellColumnIndex] + " = " + variableName[cellColumnIndex] + ";\n";
                                        javaFile += "\t}\n";
                                    }
                                }
                            }
                            if (variableType[cellColumnIndex].Equals("JSONArray"))
                            {
                                javaFile += "\tpublic " + variableType[cellColumnIndex] + " get" + strName + "() {" + "\n";
                                javaFile += "\t\treturn " + variableName[cellColumnIndex] + ";\n";
                                javaFile += "\t}\n";

                                javaFile += "\tpublic void set" + strName + "(" + variableType[cellColumnIndex] + " " + variableName[cellColumnIndex] + ") {" + "\n";
                                javaFile += "\t\tthis." + variableName[cellColumnIndex] + " = " + variableName[cellColumnIndex] + ";\n";
                                javaFile += "\t}\n";
                            }
                        }
                    }

                    // Add Init() Info To CS
                    // Get variableDefaultValue array
                    // the fourth row is variableDefaultValue
                    javaFile += "\t@Override" + "\n";
                    javaFile += "\tpublic String toString() {" + "\n";
                    javaFile += "\t\treturn \"" + ExcelFileName + " [title=\" + title" + "\n";
                    foreach (Cell cell in rowcollection.ElementAt(4).Descendants<Cell>())
                    {
                        int cellColumnIndex = GetColumnIndex(GetColumnName(cell.CellReference));
                        if (cellColumnIndex >= 1)
                        {
                            if (variableType[cellColumnIndex].Equals("int") || variableType[cellColumnIndex].Equals("float") ||
                               variableType[cellColumnIndex].Equals("double") || variableType[cellColumnIndex].Equals("long") ||
                               variableType[cellColumnIndex].Equals("String") || variableType[cellColumnIndex].Equals("boolean"))
                            {
                                if (variableLength[cellColumnIndex].Equals(""))
                                {
                                    javaFile += "\t\t\t+ \", " + variableName[cellColumnIndex] + "=\" + " + variableName[cellColumnIndex] + "\n";
                                }
                                else
                                {
                                    if (variableType[cellColumnIndex].Equals("float"))
                                    {
                                        javaFile += "\t\t\t+ \", " + variableName[cellColumnIndex] + "=\" + " + variableName[cellColumnIndex] + "\n";
                                    }
                                    else
                                    {
                                        javaFile += "\t\t\t+ \", " + variableName[cellColumnIndex] + "=\" + Arrays.toString(" + variableName[cellColumnIndex] + ")" + "\n";
                                    }
                                }
                            }

                            if (variableType[cellColumnIndex].Equals("JSONArray"))
                            {
                                javaFile += "\t\t\t+ \", " + variableName[cellColumnIndex] + "=\" + " + variableName[cellColumnIndex];
                            }
                        }
                    }
                    javaFile += " + \"]\";\n\t}\n";
                }
                return javaFile;
            }
            catch (IOException ex)
            {
                throw new IOException(ex.Message);
            }
        }

        /// <summary>
        ///  Get Value of Cell 
        /// </summary>
        /// <param name="spreadsheetdocument">SpreadSheet Document Object</param>
        /// <param name="cell">Cell Object</param>
        /// <returns>The Value in Cell</returns>
        private static string GetValueOfCell(SpreadsheetDocument spreadsheetdocument, Cell cell)
        {
            // Get value in Cell
            SharedStringTablePart sharedString = spreadsheetdocument.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
            {
                return string.Empty;
            }

            string cellValue = cell.CellValue.InnerText;

            // The condition that the Cell DataType is SharedString
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return sharedString.SharedStringTable.ChildElements[int.Parse(cellValue)].InnerText;
            }
            else
            {
                return cellValue;
            }
        }


        /// <summary>
        /// Get Column Name From given cell name
        /// </summary>
        /// <param name="cellReference">Cell Name(For example,A1)</param>
        /// <returns>Column Name(For example, A)</returns>
        private string GetColumnName(string cellReference)
        {
            // Create a regular expression to match the column name of cell
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellReference);
            return match.Value;
        }

        /// <summary>
        /// Get Index of Column from given column name
        /// </summary>
        /// <param name="columnName">Column Name(For Example,A or AA)</param>
        /// <returns>Column Index</returns>
        private int GetColumnIndex(string columnName)
        {
            int columnIndex = 0;
            int factor = 1;

            // From right to left
            for (int position = columnName.Length - 1; position >= 0; position--)
            {
                // For letters
                if (Char.IsLetter(columnName[position]))
                {
                    columnIndex += factor * ((columnName[position] - 'A') + 1) - 1;
                    factor *= 26;
                }
            }

            if ((columnName.Length - 1) >= 1)
            {
                //columnIndex += 1 + (columnName[columnName.Length - 2] - 'A');
                columnIndex += 1;
            }

            return columnIndex;
        }
    }
}
